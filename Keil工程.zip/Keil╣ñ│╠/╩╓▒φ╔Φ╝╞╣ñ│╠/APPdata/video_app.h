#ifndef __VIDEO_APP_H
#define __VIDEO_APP_H

void VIDEO_Bad_apple(void);
void VIDEO_write_Bad_apple(void);

void VIDEO_CXUK(void);
void VIDEO_write_CXUK(void);

void VIDEO_custom(void);
void VIDEO_write_custom(void);
void VIDEO_erase(void);

void VIDEO_streaming(void);

#endif

